@section('title', __('Eventos'))
@extends('layouts.backoffice')
@section('styles')
    @parent
@endsection
@section('content')
    <script src="https://kit.fontawesome.com/e1fa782e3f.js" crossorigin="anonymous"></script>
    <style>
        .list-group li button {
            border: none;
            background: none;
            outline-style: none;
            transition: all 0.5s;
        }

        .list-group li button:hover {
            cursor: pointer;
            font-size: 15px;
            transition: all 0.5s;
            font-weight: bold
        }

        .subLink {
            list-style: none;
            transition: all 0.5s;
            border-bottom: none;
        }

        .subLink:hover {
            cursor: pointer;
            font-size: 15px;
            transition: all 0.5s;
            border-bottom: #dfdfdf 1px solid;
        }
    </style>




    <div class="content-panel" style="padding:0">
        @include('Cms::access-control.navbar')
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-1">
                    <div class="col-sm-6">
                        <h1>Controle de acesso</h1>
                    </div>
                    <div class="col-sm-6">

                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col">

                        
                        <table id="events-table" class="table table-striped table-hover">
                            <thead>
                                <tr>
                                   
                                    <th>Nome completo</th>
                                    <th>Nome do utilizador</th>
                                    <th>email</th>
                                    <th>Data de acesso</th>
                                    <th>@lang('common.actions')</th>
                                </tr>
                            </thead>
                        </table>

                    </div>
                </div>
            </div>
        </div>



        
    </div>






    </div>

@endsection
@section('scripts')

    @parent
    {{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script> --}}

    <script>



        $(function() {
            $('#events-table').DataTable({
                ajax: '{!! route('access-control.ajax') !!}',
                buttons: [
                    'colvis',
                    'excel'
                ],
                columns: [{
                    data: 'full_name',
                    name: 'full_name.value'
                }
                , 
              
                {
                    data: 'user_name',
                    name: 'u.name'
                }, {
                    data: 'email',
                    name: 'u.email'
                },
                {
                    data: 'acess_data',
                    name: 'log.data'
                } , {
                    data: 'actions',
                    name: 'action',
                    orderable: false,
                    searchable: false
                }],
                searching:true,
                language: {
                    url: '{{ asset('lang/datatables/' . App::getLocale() . '.json') }}',
                }
            });
        });

        // Delete confirmation modal
        Modal.confirm('{!! Request::fullUrl() !!}/', '{!! csrf_token() !!}');

        

    </script>



@endsection
