<a href="{{ route('menus.show', $item->id) }}" class="btn btn-info btn-sm">
    @icon('far fa-eye')
</a>

